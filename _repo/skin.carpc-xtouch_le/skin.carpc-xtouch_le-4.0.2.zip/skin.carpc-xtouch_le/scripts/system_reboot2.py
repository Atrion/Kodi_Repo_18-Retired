import os
import xbmc

xbmc.executebuiltin('XBMC.Quit');
os.system("shutdown -r now &");
