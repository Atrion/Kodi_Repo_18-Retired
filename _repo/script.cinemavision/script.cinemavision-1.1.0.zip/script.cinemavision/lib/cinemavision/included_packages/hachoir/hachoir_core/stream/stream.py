from hachoir_core.error import HachoirError

class StreamError(HachoirError):
    pass

