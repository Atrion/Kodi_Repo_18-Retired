<p align="center">
<img src="https://github.com/BigNoid/Aeon-Nox/raw/master/media/aeon-nox-logo.png" width="400" align="middle">
</p>

# Aeon Nox: A skin for XBMC/Kodi

[![paypal](https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=DYAH75J73YP36)
bitcoin donation: 16H2h3RvouuL3wSeJoujk7YtzFEnCaa1z3

## Main features:
- Customisable main menu/submenu
- Customisable widgets
- Customisable backgrounds.
- Up to 14 different views available.
- Skin integration for popular add-ons.
- Master branch aims to be up-to-date with latest Kodi core changes.


<p align="center">
<img src="https://raw.githubusercontent.com/BigNoid/Aeon-Nox/master/resources/fanart.jpg">
</p>



